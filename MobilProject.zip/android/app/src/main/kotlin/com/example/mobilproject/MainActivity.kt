package com.example.mobilproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
