import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

// Ana uygulama widget'ı
class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Kart Tasarımlı Kategorili Liste',
      debugShowCheckedModeBanner: false,
      home: CategoryCardPage(),
    );
  }
}

// Kart tasarımıyla kategorili liste
class CategoryCardPage extends StatelessWidget {
  // Kategoriler ve altındaki öğeleri tutan Map yapısı
  final Map<String, List<String>> categories = {
    'Meyveler': ['🍎 Elma', '🍌 Muz', '🍊 Portakal', '🍓 Çilek'],
    'Sebzeler': ['🍅 Domates', '🥒 Salatalık', '🌶️ Biber', '🍆 Patlıcan'],
    'İçecekler': ['💧 Su', '🥤 Kola', '🍹 Meyve Suyu', '🥛 Ayran'],
  };

  @override
  Widget build(BuildContext context) {
    List<Widget> itemList = [];

    categories.forEach((kategoriAdi, ogelerListesi) {
      // Kategori başlığı
      itemList.add(
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 10.0),
          child: Text(
            kategoriAdi,
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.teal,
            ),
          ),
        ),
      );

      // Alt öğeleri kartlar olarak göster
      for (String oge in ogelerListesi) {
        itemList.add(
          Padding(
            padding:
                const EdgeInsets.symmetric(horizontal: 16.0, vertical: 6.0),
            child: Card(
              elevation: 4,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: ListTile(
                //leading: Icon(Icons.category, color: Colors.teal),
                title: Text(
                  oge,
                  style: TextStyle(fontSize: 18),
                ),
                trailing: Icon(Icons.arrow_forward_ios, size: 16),
                onTap: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('$oge seçildi')),
                  );
                },
              ),
            ),
          ),
        );
      }
    });

    return Scaffold(
      appBar: AppBar(
        title: Text('Kategorili Liste (Kart Tasarım)'),
        backgroundColor: Colors.teal,
      ),
      body: ListView(
        children: itemList,
      ),
    );
  }
}
